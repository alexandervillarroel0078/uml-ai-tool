package com.test.dtos;

import java.util.*;
import java.time.*;   // 👈 Import para LocalDate y LocalDateTime

public class AutoDto {


    private Integer nropasajeros;



    public Integer getNropasajeros() {
        return nropasajeros;
    }

    public void setNropasajeros(Integer nropasajeros) {
        this.nropasajeros = nropasajeros;
    }

}